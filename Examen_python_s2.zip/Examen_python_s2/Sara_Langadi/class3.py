import tkinter as tk


class Employee:
    

    def __init__(self, name, age, salary, job_title, department):
        self.name = name
        self.age = age
        self.salary = salary
        self.job_title = job_title
        self.department = department
        self.is_manager = False
        self.hours_worked = 0
        self.email = None
        self.phone_number = None

        # Increment the num_employees class attribute
        Employee.num_employees += 1

    # Getter methods
    def get_name(self):
        return self.name

    def get_age(self):
        return self.age

    def get_salary(self):
        return self.salary

    def get_job_title(self):
        return self.job_title

    def get_department(self):
        return self.department

    # Setter methods
    def set_name(self, name):
        self.name = name

    def set_age(self, age):
        self.age = age

    def set_salary(self, salary):
        self.salary = salary

    def set_job_title(self, job_title):
        self.job_title = job_title

    def set_department(self, department):
        self.department = department

    # Other methods
    def work(self, hours):
        self.hours_worked += hours
        print(f"{self.name} worked {hours} hours. Total hours worked: {self.hours_worked}")

    def promote(self):
        if self.is_manager:
            print("This employee is already a manager.")
        else:
            self.is_manager = True
            print(f"{self.name} has been promoted to manager.")

    def send_email(self, message):
        if not self.email:
            print(f"{self.name} does not have an email address on file.")
        else:
            print(f"Email sent to {self.email}: {message}")

    def set_contact_info(self, email, phone_number):
        self.email = email
        self.phone_number = phone_number

    def check_pay_raise(self):
        if self.salary < 50000:
            print(f"{self.name} is due for a pay raise.")
        else:
            print(f"{self.name} does not need a pay raise at this time.")

    def __str__(self):
        return f"{self.name} ({self.job_title} in {self.department})"
