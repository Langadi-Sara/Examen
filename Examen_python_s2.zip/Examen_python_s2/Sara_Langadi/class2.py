import tkinter as tk

class Car:
    

    def __init__(self, make, model, year, color, price):
        self.make = make
        self.model = model
        self.year = year
        self.color = color
        self.price = price
        self.sold = False
        self.mileage = 0
        self.features = []

        # Increment the car count class attribute
        Car.car_count += 1

    # Getter and setter methods for the mileage attribute
    def get_mileage(self):
        return self.mileage

    def set_mileage(self, new_mileage):
        if self.sold:
            print("Sorry, this car has already been sold.")
        else:
            self.mileage = new_mileage

    # Method to add a feature to the car
    def add_feature(self, feature):
        self.features.append(feature)

    # Method to print the car's features
    def print_features(self):
        print("This car has the following features:")
        for feature in self.features:
            print(f"- {feature}")

    # Method to check if the car is expensive (price > 25000)
    def is_expensive(self):
        return self.price > 25000

    # Method to print the car's make, model, and year
    def print_info(self):
        print(f"{self.make} {self.model} ({self.year})")

    # Method to sell the car
    def sell(self):
        self.sold = True
        print(f"The {self.make} {self.model} has been sold!")

    # Method to check if the car has been sold
    def is_sold(self):
        return self.sold

    # Method to calculate the depreciation of the car
    def calculate_depreciation(self, years):
        depreciation = self.price * 0.1 * years
        return self.price - depreciation

    # Method to print the car's color
    def print_color(self):
        print(f"The {self.make} {self.model} is {self.color}.")

    # Method to check if the car is a classic (year < 1980)
    def is_classic(self):
        return self.year < 1980

    # Method to print the car's price
    def print_price(self):
        print(f"The {self.make} {self.model} costs ${self.price:,.2f}.")

