import os
import platform
import sys

import tkinter as tk
from class1 import Student
from class2 import Car
from class3 import Employee




class MyApp:
    def __init__(self):
        self.running = False

    def start(self):
        self.running = True
        print("Starting application...")

    def use(self):
        if not self.running:
            print("Application is not running.")
            return

        print("Using application...")

    def quit(self):
        self.running = False
        print("Quitting application.")
