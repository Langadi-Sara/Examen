import tkinter as tk

class Student:
    def __init__(self, master):
        self.master = master
        self.master.title("Étudiants")
        self.label = tk.Label(self.master, text="Étudiants")
        self.label.pack()
        self.students = []

        # Créer une zone de texte pour afficher les étudiants
        self.students_textbox = tk.Text(self.master, height=10, width=50)
        self.students_textbox.pack()

        # Créer les champs pour les données des étudiants
        fields = [("Nom :", "name"), ("Prénom :", "firstname"), ("Numéro d'étudiant :", "student_number"), ("Année en cours :", "current_year")]
        for label_text, attr_name in fields:
            label = tk.Label(self.master, text=label_text)
            label.pack()
            entry = tk.Entry(self.master)
            setattr(self, f"{attr_name}_entry", entry)
            entry.pack()

        # Bouton pour ajouter un étudiant
        self.add_student_button = tk.Button(self.master, text="Ajouter un étudiant", command=self.add_student)
        self.add_student_button.pack()

        # Bouton pour afficher les étudiants
        self.show_students_button = tk.Button(self.master, text="Afficher les étudiants", command=self.show_students)
        self.show_students_button.pack()

    def add_student(self):
        # Récupérer le nom, le prénom, le numéro d'étudiant et l'année en cours de l'étudiant à ajouter
        name = self.name_entry.get()
        firstname = self.firstname_entry.get()
        student_number = int(self.student_number_entry.get())
        current_year = int(self.current_year_entry.get())

        # Créer un objet Student à partir des données saisies
        student = Student(self.master)
        student.nom = name
        student.prenom = firstname
        student.numero_etudiant = student_number
        student.annee_en_cours = current_year

        # Ajouter l'étudiant à la liste
        self.students.append(student)
        self.students_textbox.insert(tk.END, f"{student.prenom} {student.nom} a été ajouté à la liste des étudiants.\n")

        # Vider les champs de saisie
        for attr_name in ("name", "firstname", "student_number", "current_year"):
            getattr(self, f"{attr_name}_entry").delete(0, tk.END)

    def show_students(self):
        # Afficher tous les étudiants dans la zone de texte
        if len(self.students) == 0:
            self.students_textbox.insert(tk.END, "Il n'y a pas de etudiants dans la liste.\n")
  
        else:
                self.student_textbox.insert(tk.END, "Liste des professeurs :\n")
        for prof in self.students:
                    self.profs_textbox.insert(tk.END, f"- {Student.prenom} {Student.nom}  (les modules: {Student.modules} , {Student.experience} années d'expérience)\n")